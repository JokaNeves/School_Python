#Exercício 1
#print("Bom dia!") 

#Exercício 2
#nome = input("Como te chamas?") 
#print("Olá", nome)

#Exercício 3
#nome=input("Qual é oteu primeiro nome: ")
#apelido=input("Qual é o teu apelido: ")
#print("Olá", nome, apelido)

#Exercício 4
#numero=int(input("Escreve um numero: "))
#numero1=int(input("Escreve um numero: "))
#resultado=numero1 + numero
#print("O Resultado é: ", resultado)

#Exercício 5
#numero=int(input("Escreve um numero: "))
#resultado= numero * 2
#print(resultado)

#Exercício 6
#numero=int(input("Escreve um número: "))
#resultado= numero * 2
#print("O dobro é: ", resultado)

#Exercício 7
#numero=int(input("Escreve um número: "))
#resultado= numero * 2
#print("O dobro de ", numero, "é", resultado)

#Exercício 8
#numero1= int(input("Escreve um numero: "))
#numero2= int(input("Escreve um numero: "))
#resultado= numero1 * numero2
#print(resultado)

#Exercício 9
#numero1= int(input("Escreve um numero: "))
#numero2= int(input("Escreve um numero: "))
#resultado1= numero1 / numero2
#resultado2= numero2 / numero1
#print("Divisão do primeiro pelo segundo: ", resultado1)
#print("Divisão do segundo pelo primeiro: ", resultado2)

#Exercício10
#numero1= int(input("Escreve um numero: "))
#numero2= int(input("Escreve um numero: "))
#resultado1= numero1 // numero2
#resultado2= numero2 // numero1
#print("Divisão do primeiro pelo segundo: ", resultado1)
#print("Divisão do segundo pelo primeiro: ", resultado2)

#Exercício 11
#numero1= int(input("Escreve um numero: "))
#numero2= int(input("Escreve um numero: "))
#a=numero1+numero2
#b=numero1-numero2
#c=numero1*numero2
#d=numero1/numero2
#print("Soma: ", a)
#print("Subtração: ", b)
#print("Multiplicação: ", c)
#print("Divisão: ", d)

#Exercício12
#numero1= int(input("Escreve um numero: "))
#numero2= int(input("Escreve um numero: "))
#r1=numero1/numero2
#r2=numero1//numero2
#r3=numero1 % numero2
#print("Divisão(real): ", r1)
#print("Divisão(inteira): ", r2)
#print("Resto: ", r3)

#Exercício13
#c= int(input("Escreve um numero: "))
#d= int(input("Escreve um numero: "))
#print("a: ", c)
#print("b:", d)
#c, d = d, c
#print("a: ", c)
#print("b:", d)

#Exercício14
#n=(input("Escreve um número: "))
#if type(n) == int:
#    print("A variável é um número inteiro.")
#elif type(n) == str:
#    print("A variável é uma string.")
#else:
#    print("A variável é de outro tipo.")

